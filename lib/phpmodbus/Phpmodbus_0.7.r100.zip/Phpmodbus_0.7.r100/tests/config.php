<?php
  $test_host_ip = "192.168.1.105";  
  $test_bind_client_ip = "192.168.1.106";